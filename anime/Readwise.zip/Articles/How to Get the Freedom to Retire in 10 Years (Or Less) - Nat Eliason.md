# How to Get the Freedom to Retire in 10 Years (Or Less) - Nat Eliason

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: nateliason.com
- Full Title: How to Get the Freedom to Retire in 10 Years (Or Less) - Nat Eliason
- Category: #articles

- URL: https://www.nateliason.com/blog/financial-freedom

### Highlights

- Then, there’s Financial Independence, which is whatever the current lifestyle you have costs. It’s the number where you wouldn’t have to change how you’re living at all if you left your job or stopped working. ([View Highlight](https://instapaper.com/read/1383586146/15440477))
- Finally, there’s Absolute Financial Freedom, where you have more money than you know what to do with. This level varies widely depending on your desires, but is likely some multiple of what you’re earning right now. ([View Highlight](https://instapaper.com/read/1383586146/15440495))
