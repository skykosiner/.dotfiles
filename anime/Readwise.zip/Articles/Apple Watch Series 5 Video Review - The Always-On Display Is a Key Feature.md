# Apple Watch Series 5 Video Review - The Always-On Display Is a Key Feature

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: 9to5mac.com
- Full Title: Apple Watch Series 5 Video Review - The Always-On Display Is a Key Feature
- Category: #articles
- Document Tags: #Apple  
- URL: https://9to5mac.com/2019/10/24/review-apple-watch-series-5-always-on-display-is-a-big-improvement-but-it-comes-at-a-cost-video/

### Highlights

- It’s been over a month of Apple Watch Series 5 ownership ([View Highlight](https://instapaper.com/read/1245846492/11529804))
