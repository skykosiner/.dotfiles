# 3 Habits for Creating a Better Work-Life Balance - Thomas Frank

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: thomasjfrank.com
- Full Title: 3 Habits for Creating a Better Work-Life Balance - Thomas Frank
- Category: #articles

- URL: https://thomasjfrank.com/3-habits-for-creating-a-better-work-life-balance/

### Highlights

- Take a second and imagine the burners on a stovetop. The flames that dance on these burners are created by a supply of gas. Using that gas, you can crank one burner up to full, routing the whole supply to it and creating a single, bright flame. Or, you can distribute the gas, allowing a smaller amount to go to each burner.
  This is how I think about the concept of work-life balance. ([View Highlight](https://instapaper.com/read/1436656462/17202825))
- It’s often called the Four Burners Theory; each of us has a certain supply of gas – time, energy, motivation – and whether due to our daily choices or our obligations, that gas is distributed to four different burners:
  Work
  Health
  Relationships
  Hobbies ([View Highlight](https://instapaper.com/read/1436656462/17202841))
- When you want to do something in a balanced way, get in the habit of setting up an obligation that encourages that balance. ([View Highlight](https://instapaper.com/read/1436656462/17313303))
- So I create deadlines for my videos, but also push myself to improve at least one thing with each new video – which I then write down in my 1% Rule Log. ([View Highlight](https://instapaper.com/read/1436656462/17313304))
- This combination of the deadlines and the log ensures that I’m never resting on my laurels, making content that isn’t pushing my skills – but also that I’m not letting my perfectionism cause me to never publish. I’ve learned from experience that trying to rely solely on self-discipline to strike this balance simply does not work as well. ([View Highlight](https://instapaper.com/read/1436656462/17313306))
