# The Bright Lights of Sarajevo – iGCSE English Language Edexcel Revision – Study Rocket

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: studyrocket.co.uk
- Full Title: The Bright Lights of Sarajevo – iGCSE English Language Edexcel Revision – Study Rocket
- Category: #articles

- URL: https://studyrocket.co.uk/revision/igcse-english-language-edexcel/paper-two-reading/the-bright-lights-of-sarajevo

### Highlights

- However, there was conflict ([View Highlight](https://instapaper.com/read/1480244637/18679798))
