# Are We Too Busy to Enjoy Life?

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: nesslabs.com
- Full Title: Are We Too Busy to Enjoy Life?
- Category: #articles

- URL: https://nesslabs.com/too-busy-to-enjoy-life

### Highlights

- But many people do have this flexibility, and yet rush from one task to another without ever taking a step back to ask: am I really enjoying any of this? Or are these tasks actually making me too busy to enjoy life? ([View Highlight](https://instapaper.com/read/1384507452/15440553))
