# How to Build a Second Brain

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: aliabdaal.com
- Full Title: How to Build a Second Brain
- Category: #articles
- Document Tags: #Producitvy  
- URL: https://aliabdaal.com/how-to-build-a-second-brain-271393/

### Highlights

- How many brilliant ideas have you had and forgotten? How many insights have you failed to take action on? How much useful advice have you slowly forgotten as the years have passed?
  We feel a constant pressure to be learning, improving ourselves, and making progress. We spend countless hours every year reading, listening, and watching informational content. And yet, where has all that valuable knowledge gone? Where is it when we need it? Our brain can only store a few thoughts at any one time. Our brain is for having ideas, not storing them.
  Building A Second Brain is a methodology for saving and systematically reminding us of the ideas, inspirations, insights, and connections we’ve gained through our experience. It expands our memory and our intellect using the modern tools of technology and networks. ([View Highlight](https://instapaper.com/read/1344807026/14185234))
