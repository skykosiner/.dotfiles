# Analyst Predicts iPhone 12 ‘Supercycle’ Driven by a 'Perfect Storm' for Upgrades - 9to5Mac

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: 9to5mac.com
- Full Title: Analyst Predicts iPhone 12 ‘Supercycle’ Driven by a 'Perfect Storm' for Upgrades - 9to5Mac
- Category: #articles
- Document Tags: #Apple  
- URL: https://9to5mac.com/2020/03/03/iphone-12-upgrade-supercycle/

### Highlights

- t seemingly t ([View Highlight](https://instapaper.com/read/1283536108/12713631))
- sh analy ([View Highlight](https://instapaper.com/read/1283536108/12713632))
- s re-rating r ([View Highlight](https://instapaper.com/read/1283536108/12713633))
- as the ([View Highlight](https://instapaper.com/read/1283536108/12713634))
- 2 to 18 months.” ([View Highlight](https://instapaper.com/read/1283536108/12713635))
