# Seek Buyers, Not Followers - Nat Eliason

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: nateliason.com
- Full Title: Seek Buyers, Not Followers - Nat Eliason
- Category: #articles

- URL: https://www.nateliason.com/blog/buyers-not-followers

### Highlights

- buyers are. If you're a personal trainer trying to attract clients who will pay $100+ per hour for your services, do you suppose those ([View Highlight](https://instapaper.com/read/1385907195/15461580))
