# Eloquent JavaScript

![](https://images-na.ssl-images-amazon.com/images/I/51jvMXBl5EL._SL200_.jpg)

### Metadata

- Author: Marijn Haverbeke
- Full Title: Eloquent JavaScript
- Category: #books

### Highlights

- A typical modern computer has more than 30 billion bits in its volatile data storage (working memory). Non-volatile storage (the hard disk or equivalent) tends to have yet a few orders of magnitude more. ([Location 510](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=510))
- JavaScript uses a fixed number of bits, 64 of them, to store a single number value. There are only so many patterns you can make with 64 bits, which means that the number of different numbers that can be represented is limited. With N decimal digits, you can represent 10N numbers. Similarly, given 64 binary digits, you can represent 264 different numbers, which is about 18 quintillion (an 18 with 18 zeros after it). That’s a lot. ([Location 523](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=523))
- The + and * symbols are called operators. ([Location 544](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=544))
    - **Tags:** #orange
- Putting an operator between two values will apply it to those values and produce a new value. ([Location 546](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=546))
    - **Tags:** #orange
- As you might have guessed, the multiplication happens first. But as in mathematics, you can change this by wrapping the addition in parentheses. ([Location 548](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=548))
    - **Tags:** #orange
- For subtraction, there is the - operator, and division can be done with the / operator. ([Location 550](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=550))
    - **Tags:** #orange
- The % symbol is used to represent the remainder operation. X % Y is the remainder of dividing X by Y. ([Location 558](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=558))
    - **Tags:** #orange
- For example, 314 % 100 produces 14, and 144 % 12 gives 0. ([Location 560](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=560))
    - **Tags:** #orange
- There are three special values in JavaScript that are considered numbers but don’t behave like normal numbers. ([Location 564](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=564))
- The first two are Infinity and -Infinity, which represent the positive and negative infinities. Infinity - 1 is still Infinity, and so on. Don’t put too much trust in infinity-based computation, though. It isn’t mathematically sound, and it will quickly lead to the next special number: NaN. ([Location 565](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=565))
- NaN stands for “not a number,” even though it is a value of the number type. You’ll get this result when you, for example, try to calculate 0 / 0 (zero divided by zero), Infinity - Infinity, or any number of other numeric operations that don’t yield a meaningful result. ([Location 569](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=569))
- whenever a backslash (\) is found inside quoted text, it indicates that the character after it has a special meaning. This is called escaping the character. A quote that is preceded by a backslash will not end the string but be part of it. When an n character occurs after a backslash, it is interpreted as a newline. Similarly, a t after a backslash means a tab character. Take the following string: ([Location 580](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=580))
- If two backslashes follow each other, they will collapse together, and only one will be left in the resulting string value. ([Location 588](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=588))
- "A newline character is written like "\n"." can be expressed: ([Location 589](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=589))
- "A newline character is written like \"\\n\"." ([Location 590](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=590))
- The way JavaScript does this is based on the Unicode standard. ([Location 592](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=592))
- This standard assigns a number to virtually every character you would ever need, including characters from Greek, Arabic, Japanese, Armenian, and so on. If we have a number for every character, a string can be described by a sequence of numbers. ([Location 592](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=592))
- But Unicode defines more characters than that—about twice as many, at this point. ([Location 595](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=595))
- So some characters, such as many emoji, take up two “character positions” in JavaScript strings. ([Location 596](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=596))
- String values have a number of associated functions (methods) that can be used to perform other operations on them. I’ll say more about these in “Methods” on page 62. ([Location 601](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=601))
- Strings written with single or double quotes behave very much the same—the only difference is in which type of quote you need to escape inside of them. Backtick-quoted strings, usually called template literals, can do a few more tricks. Apart from being able to span lines, they can also embed other values. ([Location 603](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=603))
- When you write something inside ${} in a template literal, its result will be computed, converted to a string, and included at that position. ([Location 606](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=606))
- Not all operators are symbols. ([Location 609](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=609))
- One example is the typeof operator, which produces a string value naming the type of the value you give it. ([Location 610](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=610))
- console.log(typeof 4.5) // → number console.log(typeof "x") // → string ([Location 611](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=611))
- Operators that use two values are called ([Location 615](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=615))
- binary operators, while those that take one are called unary operators. ([Location 615](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=615))
- console.log(- (10 - 2)) // → -8 ([Location 617](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=617))
- Here is one way to produce Boolean values: console.log(3 > 2) // → true console.log(3 < 2) // → false ([Location 621](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=621))
- Other similar operators are >= (greater than or equal to), <= (less than or equal to), == (equal to), and != (not equal to). console.log("Itchy" != "Scratchy") ([Location 630](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=630))
- There is only one value in JavaScript that is not equal to itself, and that is NaN (“not a number”). ([Location 634](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=634))
- The && operator represents logical and. It is a binary operator, and its result is true only if both the values given to it are true. ([Location 641](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=641))
- console.log(true && false) // → false console.log(true && true) // → true ([Location 643](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=643))
- The || operator denotes logical or. It produces true if either of the values given to it is true. ([Location 644](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=644))
- console.log(false || true) // → true console.log(false || false) // → false ([Location 645](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=645))
- console.log(true ? 1 : 2); // → 1 console.log(false ? 1 : 2); // → 2 ([Location 657](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=657))
- This one is called the conditional operator (or sometimes just the ternary operator since it is the only such operator in the language). ([Location 658](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=658))
- The value on the left of the question mark “picks” which of the other two values will come out. ([Location 659](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=659))
- There are two special values, written null and undefined, that are used to denote the absence of a meaningful value. ([Location 661](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=661))
- They are ([Location 663](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=663))
- themselves values, but they carry no information. ([Location 663](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=663))
- The difference in meaning between undefined and null is an accident of JavaScript’s design, and it doesn’t matter most of the time. ([Location 665](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=665))
- In cases where you actually have to concern yourself with these values, I recommend treating them as mostly interchangeable. ([Location 667](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=667))
- When something that doesn’t map to a number in an obvious way (such as "five" or undefined) is converted to a number, you get the value NaN. ([Location 679](https://readwise.io/to_kindle?action=open&asin=B07C96Q217&location=679))
