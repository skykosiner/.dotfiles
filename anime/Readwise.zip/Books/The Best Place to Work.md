# The Best Place to Work

![](https://images-na.ssl-images-amazon.com/images/I/41jb-T96GBL._SL200_.jpg)

### Metadata

- Author: Ron Friedman PhD
- Full Title: The Best Place to Work
- Category: #books

### Highlights

- 401(k) plans, ([Location 143](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=143))
    - **Note:** What exactly is a 401k?
- The more invested and enthusiastic people are about their work, the more successful their organization is on a variety of metrics. ([Location 145](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=145))
- Studies indicate that happy employees are more productive, more creative, and provide better client service. ([Location 146](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=146))
- We know that decorating your office can make you more productive, that going for a walk can lead to better decisions, and that embracing failure can actually help you succeed. ([Location 170](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=170))
- It requires an environment that harnesses intelligence, creativity, and interpersonal skill. ([Location 180](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=180))
- In a world where productivity hinges on the quality of an employee’s thinking, psychological factors are no longer secondary. They’re at the very core of what determines success. ([Location 181](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=181))
- psychological insight can transform any organization into a great workplace. ([Location 211](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=211))
- The secret to happy workplaces isn’t spending more money. It’s about creating the conditions that allow employees to do their best work. ([Location 212](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=212))
- When your attempt rate is high, each individual failure becomes a lot less significant. ([Location 283](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=283))
- Accepting failure doesn’t just make risk-taking easier. In a surprising number of instances, it’s the only reliable path to success. ([Location 289](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=289))
- Importantly, not every one of their creations was a masterpiece. ([Location 306](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=306))
- Creative geniuses simply do not generate masterpieces on a regular basis. ([Location 307](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=307))
- The more solutions you generate, the more likely you are to stumble upon a winning combination that lives on, ([Location 312](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=312))
- because it is considered both novel and useful. ([Location 312](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=312))
- Yet “slim” is a vast improvement over my current odds. ([Location 315](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=315))
- Because in the absence of quantity, my chances are nil. ([Location 315](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=315))
- Creative geniuses don’t just attempt more solutions—they also miss quite often. ([Location 316](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=316))
- When practice is effortless, Coyle argues, learning stops. It’s by walking the precipice between your current abilities and the skills just beyond your reach that growth happens. ([Location 332](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=332))
- Master performers don’t get to where they are by playing at the same level day ([Location 333](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=333))
- after day. They do so by risking failure and using the feedback to master new skills. ([Location 334](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=334))
- “Even if you fail at your ambitious thing, it’s very hard to fail completely. That’s the thing that people don’t get.” ([Location 342](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=342))
- Blakely was taught to interpret failure not as a sign of personal weakness but as an integral part of the learning process. ([Location 367](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=367))
- We’re implicitly taught that struggling means others will view us poorly, when in reality it’s only by stretching ourselves that we develop new skills. ([Location 375](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=375))
- Failure, per se, is not enough. The important thing is to mine the failure for insight that can improve your next attempt. ([Location 385](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=385))
    - **Note:** look at your failures see what made you fail and take that as a lesson to improve
- When people are in an approach mind-set, their focus is on achieving positive outcomes, because they see the potential for gain. ([Location 409](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=409))
- Our motivational mind-set is particularly critical when we’re engaged in creative activities. ([Location 418](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=418))
- Research shows that when we’re energized by the possibility of gain, we adopt a flexible cognitive style that allows us to easily switch between mental categories. ([Location 419](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=419))
- Over the long term, encouraging employees to acknowledge mistakes is therefore a vital first step to seeing improvement. ([Location 460](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=460))
- One thing we can predict with some certainty is that the Failure CV of most high achievers tends to be surprisingly lengthy. ([Location 498](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=498))
- Sometimes the best way to minimize failure is to embrace it with open arms. ([Location 506](https://readwise.io/to_kindle?action=open&asin=B00INIYFTS&location=506))
