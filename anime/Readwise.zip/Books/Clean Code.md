# Clean Code

![](https://images-na.ssl-images-amazon.com/images/I/51d1qVhmAmL._SL200_.jpg)

### Metadata

- Author: Robert C. Martin
- Full Title: Clean Code
- Category: #books

### Highlights

- And, finally, thank you for reading these thank yous. On the ([Location 480](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=480))
- As they added more and more features, the code got worse and worse until they simply could not manage it any longer. ([Location 531](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=531))
- We’ve all looked at the mess we’ve just made and then have chosen to leave it for another day. ([Location 539](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=539))
- We’ve all felt the relief of seeing our messy program work and deciding that a working mess is better than nothing. ([Location 540](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=540))
- We’ve all said we’d go back and clean it up later. Of course, in those days we didn’t know LeBlanc’s law: Later equals never. ([Location 541](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=541))
- Over the span of a year or two, teams that were moving very fast at the beginning of a project can find themselves moving at a snail’s pace. ([Location 544](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=544))
- As the mess builds, the productivity of the team continues to decrease, asymptotically approaching zero. ([Location 548](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=548))
- As productivity decreases, management does the only thing they can; they add more staff to the project in hopes of increasing productivity. ([Location 549](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=549))
- Everyone else must continue to maintain the current system. ([Location 560](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=560))
- the fault, dear Dilbert, is not in our stars, but in ourselves. ([Location 571](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=571))
- Most managers want the truth, even when they ([Location 579](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=579))
- don’t act like it. ([Location 579](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=579))
- Most managers want good code, even when they are obsessing about the schedule. ([Location 579](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=579))
- but that’s their job. It’s your job to defend the code with equal passion. ([Location 580](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=580))
- Let’s say you believe that messy code is a significant impediment. ([Location 593](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=593))
- The bad news is that writing clean code is a lot like painting a picture. Most of us know when a picture is painted well or badly. ([Location 595](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=595))
- But being able to recognize good art from bad does not mean that we know how to paint. ([Location 596](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=596))
- So too being able to recognize clean code from dirty code does not mean that we know how to write clean code! ([Location 597](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=597))
- A programmer without “code-sense” can look at a messy module and recognize the mess but will have no idea what to do about it. ([Location 601](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=601))
- The “code-sense” will help that programmer choose the best variation and guide him or her to plot a sequence of behavior preserving transformations to get from here to there. ([Location 603](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=603))
