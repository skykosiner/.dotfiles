# Ikigai

![](https://images-na.ssl-images-amazon.com/images/I/51Hls-Umt1L._SL200_.jpg)

### Metadata

- Author: Héctor García and Francesc Miralles
- Full Title: Ikigai
- Category: #books

### Highlights

- At some point in our conversation, the mysterious word ikigai came up. This Japanese concept, which translates roughly as “the happiness of always being busy,” is like logotherapy, but it goes a step beyond. ([Location 59](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=59))
- “treat everyone like a brother, even if you’ve never met them before.” It turns out that one of the secrets to happiness of Ogimi’s residents is feeling like part of a community. ([Location 82](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=82))
- Because those who discover their ikigai have everything they need for a long and joyful journey through life. Happy travels! ([Location 89](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=89))
- Having a clearly defined ikigai brings satisfaction, happiness, and meaning to our lives. ([Location 99](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=99))
- In fact, many Japanese people never really retire—they keep doing what they love for as long as their health allows. ([Location 102](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=102))
- Having a youthful mind also drives you toward a healthy lifestyle that will slow the aging process. ([Location 199](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=199))
- Just as a lack of physical exercise has negative effects on our bodies and mood, a lack of mental exercise is bad for us because it causes our neurons and neural connections to deteriorate—and, as a result, reduces our ability to react to our surroundings. ([Location 200](https://readwise.io/to_kindle?action=open&asin=B073D36KNM&location=200))
